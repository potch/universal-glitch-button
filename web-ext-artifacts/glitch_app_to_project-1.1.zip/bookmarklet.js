hostname=location.hostname.split('.')[0];
location.href=`https://glitch.com/~${hostname}/`;